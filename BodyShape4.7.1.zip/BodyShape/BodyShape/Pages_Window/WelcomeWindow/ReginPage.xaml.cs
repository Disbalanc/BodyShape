﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BodyShape.Pages_Window.WelcomeWindow
{
    /// <summary>
    /// Логика взаимодействия для ReginPage.xaml
    /// </summary>
    public partial class ReginPage : Page
    {
        public ReginPage()
        {
            InitializeComponent();

            DataTable dt_user = Select("SELECT * FROM [dbo].[users]"); // получаем данные из таблицы
        }

        public DataTable Select(string selectSQL) // функция подключения к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase");                // создаём таблицу в приложении
                                                                            // подключаемся к базе данных
            SqlConnection sqlConnection = new SqlConnection("server=(LocalDb)\\BodyShape;Trusted_Connection=Yes;DataBase=Users;");
            sqlConnection.Open();                                           // открываем базу данных
            SqlCommand sqlCommand = sqlConnection.CreateCommand();          // создаём команду
            sqlCommand.CommandText = selectSQL;                             // присваиваем команде текст
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand); // создаём обработчик
            sqlDataAdapter.Fill(dataTable);                                 // возращаем таблицу с результатом
            return dataTable;
        }
        private void reg_Click(object sender, RoutedEventArgs e)
        {
            if (textBox_login.Text.Length > 0) // проверяем логин
            {
                if (password.Password.Length > 0) // проверяем пароль
	            {
                    if (password_copy.Password.Length > 0) // проверяем второй пароль
		            {
                        if (password.Password.Length >= 6) // проверка длины
                        {
                            DataTable dt_user = Select("SELECT * FROM [dbo].[Users] WHERE [login] = '" + textBox_login.Text + "' AND [password] = '" + password.Password + "'");
                            if (dt_user.Rows.Count > 0) // если такая запись существует       
                            {
                                MessageBox.Show("Такой пользователь существует!","Упс",MessageBoxButton.OK, MessageBoxImage.Exclamation);      
                            }
                            else
                            {
                                int result = -1;
                                SqlConnection conn = new SqlConnection("server=(LocalDb)\\BodyShape;Trusted_Connection=Yes;DataBase=Users;"); //подключение к базе
                                SqlCommand command = new SqlCommand("insert into Users(login,password) values(@login,@password)", conn); // запись данных в базу
                                command.Parameters.AddWithValue("@login", textBox_login.Text);
                                command.Parameters.AddWithValue("@password", password.Password);
                                try
                                {
                                    conn.Open();
                                    result = command.ExecuteNonQuery();
                                }
                                catch (SqlException ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                                finally
                                {
                                    conn.Close();
                                }
                            }

                        }
                        else label_password.Content = "пароль слишком короткий, минимум 6 символов";
                    }
                    else label_password_Copy.Content = "Повторите пароль";
                }
                else label_password.Content = "Укажите пароль";
            }
            else label_login.Content = "Укажите логин";
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            Login win2 = new Login();
            win2.Show();
        }
    }
}
