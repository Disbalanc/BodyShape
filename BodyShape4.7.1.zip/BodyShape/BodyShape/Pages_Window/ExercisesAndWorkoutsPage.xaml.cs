﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BodyShape.Pages_Window
{
    /// <summary>
    /// Логика взаимодействия для ExercisesAndWorkoutsPage.xaml
    /// </summary>
    public partial class ExercisesAndWorkoutsPage : Page
    {
        public ExercisesAndWorkoutsPage()
        {
            InitializeComponent();
        }
        private void Lb_Shoulders_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }
       

        private void Lb_Neck_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Lb_pectoral_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Lb_Berry_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }


        private void Lb_Quadriceps_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }


        private void Lb_Trapeze_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }


        private void Lb_Triceps_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }


        private void Lb_lats_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }


        private void Lb_Biceps_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Lb_forearms_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }


        private void Lb_BicepsShin_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Lb_Shin_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Lb_loin_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Lb_Press_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
