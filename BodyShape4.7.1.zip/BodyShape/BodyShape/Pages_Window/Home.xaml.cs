﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Globalization;

namespace BodyShape.Pages_Window
{
    /// <summary>
    /// Логика взаимодействия для Home.xaml
    /// </summary>
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();
            if (Properties.Settings.Default.UserImage != String.Empty)
            {
                UserImage.Source = new BitmapImage(new Uri(Properties.Settings.Default.UserImage));
            }
        }
        private SqlConnection conn = new SqlConnection("server=(LocalDb)\\BodyShape;Trusted_Connection=Yes;DataBase=Users;"); //подключение к базе
        private void btn_AddPicture_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog open_dialog = new OpenFileDialog(); //создание диалогового окна для выбора файла
            open_dialog.Filter = "Image Files(*.BMP;*.JPG;*.GIF;*.PNG)|*.BMP;*.JPG;*.GIF;*.PNG|All files (*.*)|*.*"; //формат загружаемого файла
            Nullable<bool> result = open_dialog.ShowDialog();
            if (result == true) //если в окне была нажата кнопка "ОК"
            {
                try
                {
                    UserImage.Source = new BitmapImage(new Uri(open_dialog.FileName));
                    Properties.Settings.Default.UserImage = open_dialog.FileName;
                    Properties.Settings.Default.Save();
                    int result1 = -1;
                    SqlCommand command = new SqlCommand("UPDATE [dbo].[Users] SET [user_image] = '" + open_dialog.FileName + "' WHERE [login] = '" + Properties.Settings.Default.Texbox_LOgin + "' AND [password] = '" + Properties.Settings.Default.passwordd + "'", conn);
                    try
                    {
                        conn.Open();
                        result1 = command.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                catch
                {
                    MessageBox.Show("Невозможно открыть выбранный файл",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Grid_MouseEnter(object sender, MouseEventArgs e)
        {
            btn_AddPicture.Visibility = Visibility.Visible;
        }

        private void Grid_MouseLeave(object sender, MouseEventArgs e)
        {
            btn_AddPicture.Visibility = Visibility.Hidden;
        }
    }
}
