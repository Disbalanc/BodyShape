﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BodyShape.Pages_Window
{
    /// <summary>
    /// Логика взаимодействия для WorkautsPage.xaml
    /// </summary>
    public partial class WorkautsPage : Page
    {
        // доделать добавление, убавление тренировок и убавление каллорий при выполнении упражнений

        int indexY = 0; //для перемещения грида
        int indexY1 = 0;

        DateTime FreeDay = DateTime.Now.Date;
        int CollWorkouts;
        public WorkautsPage()
        {
            InitializeComponent();
            DataTable dt_DateWorkout = Select("SELECT Workout_Name,Workout_URI FROM [dbo].[Workouts]"); // получаем данные из таблицы
            DG_Workouts.DataContext = dt_DateWorkout.DefaultView;
            
        }

        private void ManagesWorkauts_Click(object sender, RoutedEventArgs e)
        {
            WorkautsGrid.Margin = new Thickness(indexY -= 900, 0, indexY1 += 800, 0);
        }

        private void Workauts_Click(object sender, RoutedEventArgs e)
        {
            WorkautsGrid.Margin = new Thickness(indexY += 900, 0, indexY1 -= 800, 0);
        }

        public DataTable Select(string selectSQL) // функция подключения к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase");

            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
              "Data Source=wsr;" +
              "Initial Catalog=spirkin;" +
              "User id=spirkin;" +
              "Password=9225;";
            sqlConnection.Open();                                           
            SqlCommand sqlCommand = sqlConnection.CreateCommand();          
            sqlCommand.CommandText = selectSQL;                          
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand); 
            sqlDataAdapter.Fill(dataTable);                               
            return dataTable;
        }

        #region Workouts
        private void Workouts(int index_Workout)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
              "Data Source=wsr;" +
              "Initial Catalog=spirkin;" +
              "User id=spirkin;" +
              "Password=9225;";
            for (int i = 1; i <= 1; i++)
            {
                SqlCommand command = new SqlCommand($"Select WorkoutsDate,id_Date from [dbo].[Workout_Date] Where id_Date='" + i + "'", sqlConnection); // получаем данные из таблицы
                sqlConnection.Open();
                command.ExecuteNonQuery();
                DataTable dataTbl = new DataTable($"Select WorkoutsDate,id_Date from [dbo].[Workout_Date] Where id_Date='" + i + "'");
                DG_Workouts.DataContext = dataTbl.DefaultView;
                if (dataTbl.ToString() == FreeDay.ToString())
                {
                    MessageBox.Show($"Ура");
                }
            }
            try
            {
                

                
            }
            catch (Exception) 
            {
                sqlConnection.Close();
            }

        }
        private void btn_Shoulders_Click(object sender, RoutedEventArgs e)
        {
            Workouts(1);
        }

        private void btn_Neck_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Chest_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Press_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_SmallOfTheBack_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Gluteal_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Quadriceps_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Trapeze_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Triceps_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Lats_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Biceps_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Forearms_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_BicepsFemoris_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Shin_Click(object sender, RoutedEventArgs e)
        {

        }
        #endregion
    }
}
