﻿using BodyShape.Pages_Window.WelcomeWindow;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace BodyShape.Pages_Window.WelcomeWindow
{
    public partial class WelcomeWindow : Window
    {
        //доделано

        int indexY1 = 0; //поля для передвижения Grid
        int indexY = 0;

        private string _Target ;
        private string _targetWeight;
        private string _lifeStyle;
        private string _dateOfBirth;
        private int _weight;
        private int _height;

        #region Get Field
        public string GetTarget()
        {
            return _Target;
        }
        public string GetTargetWeight()
        {
            return _targetWeight;
        }
        public string GetLifeStyle()
        {
            return _lifeStyle;
        }
        public string GetDateOfBirth()
        {
            return _dateOfBirth;
        }
        public int GetWeight()
        {
            return _weight;
        }
        public int GetHeight()
        {
            return _height;
        }
        #endregion

        public WelcomeWindow()
        {
            InitializeComponent();
        }

        #region Button Window
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY-= 800,0,indexY1 +=800,0);
            Next.Visibility = Visibility.Collapsed;
            Next.IsEnabled = false;
            Back.IsEnabled = true;

            if (indexY1 > 3200)
            {
                Regin.Navigate(new ReginPage());
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY += 800, 0, indexY1 -= 800, 0);
            if (indexY1 <= 800)
            {
                Next.Visibility = Visibility.Visible;
                Next.IsEnabled = true;
                Back.IsEnabled = false;
            }
            if (indexY1 == 2400)
            {
                Next.Visibility = Visibility.Collapsed;
            }
        }
        
        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            Login win2 = new Login();
            win2.Show();
            this.Hide();
            if (Properties.Settings.Default.Texbox_LOgin != String.Empty)
            {
                win2.Hide();
            }
        }
        #endregion

        #region Question 0
        private void Name_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Name.Text == "Ваше имя")
            {
                Name.Foreground = Brushes.Black;
                Name.Text = string.Empty;
            }
        }
        private void Name_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (Name.Text == "Ваше имя")
            {
                Name.Foreground = Brushes.Silver;
                Name.Text = "Ваше имя";
            }
        }
        private void Name_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Name.Text.Length != 0 && Name.Text !="Ваше имя")
            {
                Next.IsEnabled = true;
            } else { Next.IsEnabled = false; }
            
        }
        #endregion

        #region Question 1
        private void loseWeight_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _Target = "Похудеть";
        }

        private void stressManagement_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _Target = "Поддержать вес";
        }

        private void maintainWeight_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _Target = "Набрать вес";
        }

        private void gainWeight_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _Target = "Набрать мышечную массу";
        }

        private void gainMuscleMass_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _Target = "Изменить мою диету";
        }

        private void changeMyDiet_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _Target = "Управлять стрессом";
        }

        private void increaseTheNumberOfSteps_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _Target = "Увеличение количество шагов";
        }
        #endregion

        #region Question 2
        private void getStrong_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _targetWeight = "Улучшение тонуса";
        }

        private void buildingMuscleMass_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _targetWeight = "Наращивание мышечной массы";
        }

        private void toneImprovements_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _targetWeight = "Стать сильным";
        }
        #endregion

        #region Question 3
        private void notVeryMobile_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _lifeStyle = "Не очень подвижный";

            Next.Content = "Зарегестрироваться";
            Next.Visibility = Visibility.Visible;
        }

        private void sedentary_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _lifeStyle = "Малоподвижный";

            Next.Content = "Зарегестрироваться";
            Next.Visibility = Visibility.Visible;
        }

        private void active_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _lifeStyle = "Активный";

            Next.Content = "Зарегестрироваться";
            Next.Visibility = Visibility.Visible;
        }

        private void veryMobile_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY -= 800, 0, indexY1 += 800, 0);
            _lifeStyle = "Очень подвижный";

            Next.Content = "Зарегестрироваться";
            Next.Visibility = Visibility.Visible;
        }
        #endregion

        #region Question 4
        private void Man_Checked(object sender, RoutedEventArgs e)
        {
            Woman.IsChecked = false;
        }

        private void Woman_Checked(object sender, RoutedEventArgs e)
        {
            Man.IsChecked = false;
        }

        private void dateOfBirth_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (dateOfBirth.Text == "Дата рождения")
            {
                dateOfBirth.Foreground = Brushes.Black;
                dateOfBirth.Text = String.Empty;
            }
        }

        private void dateOfBirth_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (dateOfBirth.Text == "Дата рождения")
            {
                dateOfBirth.Foreground = Brushes.Black;
                dateOfBirth.Text = "Дата рождения";
            }
        }

        private void dateOfBirth_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dateOfBirth.Text.Length != 0 && dateOfBirth.Text != "Дата рождения" && weight.Text != "Вес" && height.Text != "Рост" && (Man.IsChecked == true || Woman.IsChecked == true))
            {
                Next.IsEnabled = true;
            } else { Next.IsEnabled = false; }
        }

        private void weight_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (weight.Text == "Вес")
            {
                weight.Foreground = Brushes.Black;
                weight.Text = String.Empty;
            }
        }

        private void weight_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (weight.Text == "Вес")
            {
                weight.Foreground = Brushes.Black;
                weight.Text = "Вес";
            }
        }

        private void weight_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (weight.Text.Length != 0 && dateOfBirth.Text != "Дата рождения" && weight.Text != "Вес" && height.Text != "Рост" && (Man.IsChecked == true || Woman.IsChecked == true))
            {
                Next.IsEnabled = true;
            }
            else { Next.IsEnabled = false; }
        }

        private void height_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (height.Text == "Рост")
            {
                height.Foreground = Brushes.Black;
                height.Text = String.Empty;
            }
        }

        private void height_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (height.Text == "Рост")
            {
                height.Foreground = Brushes.Black;
                height.Text = "Рост";
            }
        }

        private void height_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (height.Text.Length != 0 && dateOfBirth.Text != "Дата рождения" && weight.Text != "Вес" && height.Text != "Рост" && (Man.IsChecked == true || Woman.IsChecked == true))
            {
                Next.IsEnabled = true;
            }
            else { Next.IsEnabled = false; }
        }
        #endregion

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }
    }
}
