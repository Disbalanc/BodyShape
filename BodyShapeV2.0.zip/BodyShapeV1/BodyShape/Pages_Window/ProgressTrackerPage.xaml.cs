﻿using BodyShape.Pages_Window.WelcomeWindow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BodyShape.Pages_Window
{
    /// <summary>
    /// Логика взаимодействия для ProgressTrackerPage.xaml
    /// </summary>
    public partial class ProgressTrackerPage : Page
    {
        // не доделано функция похудения и вычитание веса

        private int _targetWeidth = 1;
        private int _heigth;
        private int _weigth;
        private int _nowWeigth;
        private int _kallories;

        public ProgressTrackerPage()
        {
            InitializeComponent();
            try
            {
                WelcomeWindow.WelcomeWindow welcomeWindow = new WelcomeWindow.WelcomeWindow();
                _heigth = welcomeWindow.GetHeight();
                _weigth = welcomeWindow.GetWeight();
                _targetWeidth = _weigth / _heigth;
                Lb_targetWeidth.Content = $"Ваш целевой вес: {_targetWeidth}";
            }
            catch
            {

            }
            
        }
    }
}
