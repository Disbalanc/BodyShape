﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BodyShape.Pages_Window
{
    /// <summary>
    /// Логика взаимодействия для Settings.xaml
    /// </summary>
    public partial class Settings : Window
    {
        //настройки для пользователя, обновления базы, сохранение в Json и word file

        public Settings()
        {
            InitializeComponent();

            CB_Tables.DataContext = Select("Select TABLE_NAME From INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE'");

            Properties.Settings.Default.Texbox_LOgin = "spirkin";
            Properties.Settings.Default.passwordd = "123";

                DataTable dt_user = Select(@"SELECT * FROM [dbo].[Users] WHERE [Admin] = 'true' And [login] = '" + Properties.Settings.Default.Texbox_LOgin + "' AND [password] = '" + Properties.Settings.Default.passwordd + "'");
                if (dt_user.Rows.Count > 0)   
                {
                    btn_SettingDataBase.Visibility = Visibility.Visible;
                } 
                
        }
        
        public DataTable Select(string selectSQL) // функция подключения к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase");

            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
              "Data Source=wsr;" +
              "Initial Catalog=spirkin;" +
              "User id=spirkin;" +
              "Password=9225;";
            sqlConnection.Open();                                          
            SqlCommand sqlCommand = sqlConnection.CreateCommand();          
            sqlCommand.CommandText = selectSQL;                             
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand); 
            sqlDataAdapter.Fill(dataTable);                                 
            return dataTable;
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void btn_SettingDataBase_Click(object sender, RoutedEventArgs e)
        {
            Grid_DataBase.Margin = new Thickness(0, 0,0, 0);
            
        }

        private void btn_Setting_Click(object sender, RoutedEventArgs e)
        {
            Grid_DataBase.Margin = new Thickness(800, 0, -800, 0);
        }

        private void btn_saveFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FileStream file1 = new FileStream("d:\\BodyShape\\test.doc", FileMode.Create);
                StreamWriter writer = new StreamWriter(file1);
                writer.WriteLine(DG_Tables);
                writer.Close();
            } catch (Exception)
            {
                MessageBox.Show("В файл не было сохранено","Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }

        private void CB_Tables_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataTable dataTable = new DataTable($"SELECT * FROM [dbo].[{CB_Tables.SelectedItem}]");
            DG_Tables.ItemsSource = dataTable.DefaultView;

        }

        private void btn_updateBase_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
