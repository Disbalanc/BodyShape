﻿using BodyShape.Pages;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace BodyShape.Pages_Window.WelcomeWindow
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public DataTable Select(string selectSQL) // функция подключения к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase");                // создаём таблицу в приложении
                                                                            // подключаемся к базе данных
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
              "Data Source=wsr;" +
              "Initial Catalog=spirkin;" +
              "User id=spirkin;" +
              "Password=9225;";
            sqlConnection.Open();                                           // открываем базу данных
            SqlCommand sqlCommand = sqlConnection.CreateCommand();          // создаём команду
            sqlCommand.CommandText = selectSQL;                             // присваиваем команде текст
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand); // создаём обработчик
            sqlDataAdapter.Fill(dataTable);                                 // возращаем таблицу с результатом
            return dataTable;
        }

        public Login()
        {
            InitializeComponent();
            textBox_login.Text = Properties.Settings.Default.Texbox_LOgin;
            password.Password = Properties.Settings.Default.passwordd;
            Login1();
            DataTable dt_user = Select("SELECT * FROM [dbo].[users]"); // получаем данные из таблицы
        }

        //переход регистрации
        private void Regin_Click(object sender, RoutedEventArgs e)
        {
            Pages.WelcomeWindow welcomeWindow = new Pages.WelcomeWindow();
            welcomeWindow.Show();
            this.Close();
        }

        // вход
        private void Login_Click_1(object sender, RoutedEventArgs e)
        {
            if (textBox_login.Text.Length > 0) // проверяем введён ли логин     
            {
                if (password.Password.Length > 0) // проверяем введён ли пароль         
                {             // ищем в базе данных пользователя с такими данными         
                    DataTable dt_user = Select("SELECT * FROM [dbo].[Users] WHERE [login] = '" + textBox_login.Text + "' AND [password] = '" + password.Password + "'");
                    if (dt_user.Rows.Count > 0) // если такая запись существует       
                    {
                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                        Properties.Settings.Default.Texbox_LOgin = textBox_login.Text;
                        Properties.Settings.Default.passwordd = password.Password;
                        Properties.Settings.Default.Save();
                        this.Close();
                    }
                    else MessageBox.Show("Пользователя не найден"); // выводим ошибку  
                }
                else MessageBox.Show("Введите пароль"); // выводим ошибку    
            }
            else MessageBox.Show("Введите логин"); // выводим ошибку 
        }
        private void Login1()
        {
            if (textBox_login.Text.Length > 0) // проверяем введён ли логин     
            {
                DataTable dt_user = Select("SELECT * FROM [dbo].[Users] WHERE [login] = '" + textBox_login.Text + "' AND [password] = '" + password.Password + "'");
                if (dt_user.Rows.Count > 0) // если такая запись существует       
                {
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Hide();
                }
                else MessageBox.Show("Пользователя не найден"); // выводим ошибку
            }
        }
    }
}
