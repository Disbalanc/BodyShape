﻿using BodyShape.Pages_Window;
using BodyShape.Pages_Window.WelcomeWindow;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BodyShape.Pages
{
    public partial class WelcomeWindow : Window
    {

        int indexY1 = 0; //поля для передвижения Grid
        int indexY = 0;



        public WelcomeWindow()
        {
            InitializeComponent();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (indexY1 + 800 > 2400)
                {
                    LoginRegin.Navigate(new ReginPage());
                }
                Question.Margin = new Thickness(indexY-= 800,0,indexY1 +=800,0);

                if (indexY1 == 2400)
                {
                    Next.Content = "Зарегестрироваться";
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Что-то пошло не так","Упс",MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Question.Margin = new Thickness(indexY += 800, 0, indexY1 -= 800, 0);
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            Login win2 = new Login();
            win2.Show();
            this.Hide();
            if (Properties.Settings.Default.Texbox_LOgin != String.Empty)
            {
                win2.Hide();
            }
        }

        private void loseWeight_Click(object sender, RoutedEventArgs e)
        {

        }

        private void loseWeight_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void loseWeight_Click_2(object sender, RoutedEventArgs e)
        {

        }
    }
}
